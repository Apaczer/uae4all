 /*
  * NO SCSI device
  */
